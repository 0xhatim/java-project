/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.library_management_system;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Sozaro
 */
public class Mavenproject1 {

    public static void main(String[] args) throws Exception  {
        JFrame home = new ReportCase();
        
        home.setVisible(true);
        
    }
}
