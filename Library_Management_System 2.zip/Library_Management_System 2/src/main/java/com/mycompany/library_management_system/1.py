import os

# Define the text to be replaced
old_text = 'Amnbvcxz12#'
new_text = 'Amnbvcxz12#'

# Get a list of all files in the current directory
files = [file for file in os.listdir() if os.path.isfile(file)]

# Iterate over each file in the directory
for file in files:
    try:
            
        with open(file, "r") as f:
            # Read the content of the file
            content = f.read()

            # Replace the old text with the new text
            content = content.replace(old_text, new_text)

        with open(file, "w") as f:
            # Write the updated content back to the file
            f.write(content)
    except:
        pass

print("All files have been updated.")

