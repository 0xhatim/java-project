/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.library_management_system;


import java.awt.Color;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Sozaro
**/

public final class homePage extends javax.swing.JFrame {

    /**
     * Creates new form homePage
     */
    
    public int user_ID = 0 ;
    
    void updateView(int USER_ID){
           
          TableActionEvent event = new TableActionEvent() {
          
   
            @Override
            public void onBuy(int row) {
                System.out.println("View row : " + row);
              String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
           int price =0 ;
           
        String title_search = jTable2.getModel().getValueAt(row, 0).toString();

            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String sql = "SELECT Price FROM books WHERE Title = ?";

                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, title_search);

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                     price = resultSet.getInt("Price");
                    System.out.println("Price of " + title_search + ": " + price);
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            int book_IDD =0 ;
            
             try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String sql = "SELECT book_id FROM books WHERE Title = ?";

                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, title_search);

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                     book_IDD = resultSet.getInt("book_id");
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
           
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    

                        try (Connection conn = DriverManager.getConnection(url, username, password)) {

                            
                            String sql = "SELECT User_balance FROM users WHERE User_id = ?";

                            PreparedStatement statement = conn.prepareStatement(sql);
                            statement.setInt(1, USER_ID);

                            ResultSet resultSet = statement.executeQuery();
                                
                            while (resultSet.next()) {
                               int userBalance = resultSet.getInt("User_balance");
                                System.out.println("User balance: " + userBalance);
                                if ( userBalance >=price){
                                    userBalance =  userBalance - price ;
                                    updateUserBalance(USER_ID,userBalance);
                                    insertUserBook(USER_ID,book_IDD);
                                      //   jTable2.getModel().
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.removeRow(row);

                                    showMessageBox("Successefuly Added into your Collection \nbalance is :"+userBalance,"Success Payment");
                                    
                                }
                  else{
                                showMessageBox("Faild to pay \nbalance is :"+userBalance+"\nitem is : "+price,"Balance is not enough");

                                }
                                
                            }
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                        }
                    
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(homePage.class.getName()).log(Level.SEVERE, null, ex);
                }
    
                
                
            }
                };
                  TableActionEvent details_event = new TableActionEvent() {
          
   
            @Override
            public void onBuy(int row) {
                System.out.println("View Details : " + row);
                
                int column = 0;
                int row2 = jTable2.getSelectedRow();
                String title_search = jTable2.getModel().getValueAt(row2, column).toString();
                int count_of_buyrs = 0;
                
                try {
                     count_of_buyrs = peopleboughtit(title_search);
                } catch (ClassNotFoundException ex) {
                       ex.printStackTrace();
                } catch (SQLException ex) {
                       ex.printStackTrace();
                }
          
                
                   Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
             String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
            con = DriverManager.getConnection(url, username, password);
            // Create the SQL statement
            stmt = con.prepareStatement("SELECT Title, Description, Price , Date FROM books WHERE Title = ?");
            stmt.setString(1, title_search);
            // Execute the query
            rs = stmt.executeQuery();
            // Check if a book with the given title was found
            if (rs.next()) {
                // Get the information about the book
                String bookTitle = rs.getString("Title");
                String bookDescription = rs.getString("Description");

                int bookPrice = rs.getInt("Price");
                // Display the information in a message box
                JOptionPane.showMessageDialog(null, "Title: " + bookTitle + "\nDescription: " + bookDescription + "\nPrice: " + bookPrice+"\nCount of buyres"+count_of_buyrs, "Book Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // If the book was not found, display a message
                JOptionPane.showMessageDialog(null, "Book not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            // Handle any errors that may occur
            e.printStackTrace();
        } finally {
            // Close the resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }   
                
                
                     }
                };
        String query = "SELECT Title, Description, Price FROM books WHERE Book_id NOT IN (SELECT Book_id FROM checkout);";

        
        try{
           String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
           
           Class.forName("com.mysql.cj.jdbc.Driver");
    
        Connection con = DriverManager.getConnection(url,username,password);
        Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = st.executeQuery(query);

        DefaultTableModel model = new DefaultTableModel();
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();
       
        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
            model.addColumn(metaData.getColumnLabel(columnIndex));

        }
                model.addColumn("Buy");
                model.addColumn("Details");
columnCount = model.getColumnCount();

        /* 
        
        THIS CODE FOR COLUMN ACTION NOT INCLUDED AT TABLE DESIGNIGN PHASE 
        */     
        

        
        /*
        
        
        END OF 
        */
  
Object[] row = new Object[columnCount];


        while (rs.next()) {
    for (int columnIndex = 0; columnIndex < columnCount - 2; columnIndex++) {
                row[columnIndex] = rs.getObject(columnIndex + 1);
            }
            JButton button = new JButton("Buy");
            JButton details = new JButton("Details");

            row[columnCount -2 ] = button;
            row[columnCount -1] = details;

            model.addRow(row);
        }
            jLabel19.setText(""+model.getRowCount());

        jTable2.setModel(model);
    
        st.close();
        con.close();
        rs.close();
        
        
        
            
        } catch (ClassNotFoundException ex) {
        System.out.println(ex.toString());

        }catch(SQLException ex2){
            
                    System.out.println(ex2.toString());


            
        }        // TODO add your handling code here:
        // TODO add your handling code here: 
                
        
        jTable2.getColumnModel().getColumn(3).setCellRenderer(new TableActionCellRender());
        
        jTable2.getColumnModel().getColumn(3).setCellEditor(new TableActionCellEditor(event));        

       jTable2.getColumnModel().getColumn(4).setCellRenderer(new TableActionCellRender1());
        
        jTable2.getColumnModel().getColumn(4).setCellEditor(new TableActionCellEditor1(details_event));   
    }
    public int  userBalance= 1000;

public void showMessageBox(String message, String title) {
    JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
}

    public int peopleboughtit(String name) throws ClassNotFoundException, SQLException{
        
String bookName = "book_name";
int count = 0;
               String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
           Class.forName("com.mysql.cj.jdbc.Driver");
           
    
try (Connection conn = DriverManager.getConnection(url,username,password);

        Statement stmt = conn.createStatement();
     ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM checkout " + 
                                      "INNER JOIN books ON checkout.Book_id = books.Book_id " + 
                                      "WHERE books.Title = '" + bookName + "'")) {
    if (rs.next()) {
        count = rs.getInt(1);
    }
} catch (SQLException e) {
    e.printStackTrace();
}

return count;


        
    }
    public void updateUserBalance(int user_ID,int newBalance){
        String url = "jdbc:mysql://localhost:3306/digitalibrary";
String username = "root";
String password = "Amnbvcxz12#";


try (Connection conn = DriverManager.getConnection(url, username, password)) {
    Statement statement = conn.createStatement();
    String sql = "UPDATE users SET User_balance = " + newBalance + " WHERE User_id = " + user_ID;

    int rowCount = statement.executeUpdate(sql);
    System.out.println(rowCount + " row(s) updated");
} catch (SQLException e) {
    System.out.println(e.getMessage());
}
    }
    
    public void insertUserBook(int userId, int bookId) {
    String url = "jdbc:mysql://localhost:3306/digitalibrary";
    String username = "root";
    String password = "Amnbvcxz12#";

    try (Connection conn = DriverManager.getConnection(url, username, password)) {
        String sql = "INSERT INTO user_books (User_id, book_id) VALUES (?,?)";
        Statement statement = conn.createStatement();
        statement.executeUpdate(sql);
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
}
    public homePage(int USER_ID) throws Exception {
        initComponents();
        setDefaultCloseOperation(2);
     
/*
          

          */

          this.user_ID=USER_ID;

    // Submit a task to the executor
                try{
                updateComboBox();
                updateView(USER_ID);                  
                }catch(Exception e){
                    System.out.println(e.getMessage());
                }
  
    
    

        
        
    }
    
     private  void updateComboBox() throws Exception {
 
        
            String sql = "SELECT name FROM category";

 
            
    
        try{
           String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
           
           Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con = DriverManager.getConnection(url,username,password);
        Statement st = con.createStatement();

     PreparedStatement statement = con.prepareStatement(sql);
          var resultSet = statement.executeQuery();

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            while (resultSet.next()) {
                System.out.println(resultSet.getString("name"));
                
                model.addElement(resultSet.getString("name"));
            }
                 model.addElement("other");

            jComboBox1.setModel(model);

    
        st.close();
        con.close();
        
        
            
        } catch (ClassNotFoundException ex) {
        System.out.println(ex.toString());

        }catch(SQLException ex2){
            
                    System.out.println(ex2.toString());


            
        }  
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        sidebar = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        SearchTools = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(1, 0), new java.awt.Dimension(1, 0), new java.awt.Dimension(1, 32767));
        jLabel14 = new javax.swing.JLabel();
        BookName = new javax.swing.JTextField();
        minPrice = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        maxPrice = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Results = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("DIGITAL LIBRARY");
        setLocationByPlatform(true);
        setName("DigitalLibrary"); // NOI18N
        setResizable(false);

        bg.setBackground(new java.awt.Color(255, 255, 255));

        sidebar.setBackground(new java.awt.Color(54, 33, 89));
        sidebar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(64, 43, 100));
        jPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel2MouseClicked(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(64, 43, 100));
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Report a problem");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel2)
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(20, 20, 20))
        );

        sidebar.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 240, 50));

        jPanel3.setBackground(new java.awt.Color(85, 65, 118));
        jPanel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel3MouseClicked(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Explore our library");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel4)
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(20, 20, 20))
        );

        sidebar.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 240, 50));

        jPanel4.setBackground(new java.awt.Color(64, 43, 100));
        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel4MouseClicked(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Your collection");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel6)
                .addContainerGap(72, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(20, 20, 20))
        );

        sidebar.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 240, 50));

        jPanel5.setBackground(new java.awt.Color(64, 43, 100));
        jPanel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel5MouseClicked(evt);
            }
        });

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Ask for refund");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel8)
                .addContainerGap(75, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(13, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(20, 20, 20))
        );

        sidebar.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 240, 50));

        jLabel11.setFont(new java.awt.Font("PT Sans Caption", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("DIGITAL LIBRARY");
        sidebar.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, 40));
        sidebar.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 120, 10));

        jPanel1.setBackground(new java.awt.Color(122, 72, 221));

        jLabel9.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Find your passion here");

        jLabel10.setFont(new java.awt.Font("Raanana", 2, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("When in doubt go to the library.");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(231, 231, 231))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        SearchTools.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setText("Choice Category ");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CyberSecurity" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel14.setText("Book Name");

        minPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minPriceActionPerformed(evt);
            }
        });

        jLabel15.setText("Price");

        jLabel16.setText("Min");

        jLabel17.setText("Max");

        jLabel18.setText("Results :");

        jLabel19.setText("4");

        jButton1.setText("search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SearchToolsLayout = new javax.swing.GroupLayout(SearchTools);
        SearchTools.setLayout(SearchToolsLayout);
        SearchToolsLayout.setHorizontalGroup(
            SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SearchToolsLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SearchToolsLayout.createSequentialGroup()
                        .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(SearchToolsLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(SearchToolsLayout.createSequentialGroup()
                                .addComponent(BookName, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(minPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(maxPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(SearchToolsLayout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(168, 168, 168))
        );
        SearchToolsLayout.setVerticalGroup(
            SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SearchToolsLayout.createSequentialGroup()
                .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SearchToolsLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(SearchToolsLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BookName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15)
                    .addComponent(minPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maxPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SearchToolsLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(SearchToolsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19))
                        .addContainerGap(18, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SearchToolsLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addContainerGap())))
        );

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.setRowHeight(50);
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout ResultsLayout = new javax.swing.GroupLayout(Results);
        Results.setLayout(ResultsLayout);
        ResultsLayout.setHorizontalGroup(
            ResultsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 822, Short.MAX_VALUE)
        );
        ResultsLayout.setVerticalGroup(
            ResultsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ResultsLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addComponent(sidebar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(SearchTools, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(Results, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sidebar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SearchTools, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Results, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void minPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_minPriceActionPerformed

    private void jPanel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MouseClicked
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_jPanel3MouseClicked

    private void jPanel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel2MouseClicked
        // TODO add your handling code here:
        
        
        JFrame home = new reportAproblem(this.user_ID);
        home.setDefaultCloseOperation(1);
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jPanel2MouseClicked

    private void jPanel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel5MouseClicked
           JFrame refund = new Refund(this.user_ID);
        refund.setDefaultCloseOperation(1);
        refund.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jPanel5MouseClicked

    private void jPanel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseClicked
             JFrame refund = new Collection(this.user_ID);
        refund.setDefaultCloseOperation(1);
        refund.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jPanel4MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int USER_ID = user_ID;
        
          
          TableActionEvent event = new TableActionEvent() {
          
   
            @Override
            public void onBuy(int row) {
                System.out.println("View row : " + row);
              String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
           int price =0 ;
           
        String title_search = jTable2.getModel().getValueAt(row, 0).toString();

            try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String sql = "SELECT Price FROM books WHERE Title = ?";

                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, title_search);

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                     price = resultSet.getInt("Price");
                    System.out.println("Price of " + title_search + ": " + price);
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            int book_IDD =0 ;
            
             try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String sql = "SELECT book_id FROM books WHERE Title = ?";

                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, title_search);

                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                     book_IDD = resultSet.getInt("book_id");
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
           
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    

                        try (Connection conn = DriverManager.getConnection(url, username, password)) {

                            
                            String sql = "SELECT User_balance FROM users WHERE User_id = ?";

                            PreparedStatement statement = conn.prepareStatement(sql);
                            statement.setInt(1, USER_ID);

                            ResultSet resultSet = statement.executeQuery();
                                
                            while (resultSet.next()) {
                               int userBalance = resultSet.getInt("User_balance");
                                System.out.println("User balance: " + userBalance);
                                if ( userBalance >=price){
                                    userBalance =  userBalance - price ;
                                    updateUserBalance(USER_ID,userBalance);
                                    insertUserBook(USER_ID,book_IDD);
                                      //   jTable2.getModel().
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.removeRow(row);

                                    showMessageBox("Successefuly Added into your Collection \nbalance is :"+userBalance,"Success Payment");
                                    
                                }
                  else{
                                showMessageBox("Faild to pay \nbalance is :"+userBalance+"\nitem is : "+price,"Balance is not enough");

                                }
                                
                            }
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                        }
                    
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(homePage.class.getName()).log(Level.SEVERE, null, ex);
                }
    
                
                
            }
                };
                  TableActionEvent details_event = new TableActionEvent() {
          
   
            @Override
            public void onBuy(int row) {
                System.out.println("View Details : " + row);
                
                int column = 0;
                int row2 = jTable2.getSelectedRow();
                String title_search = jTable2.getModel().getValueAt(row2, column).toString();
                int count_of_buyrs = 0;
                
                try {
                     count_of_buyrs = peopleboughtit(title_search);
                } catch (ClassNotFoundException ex) {
                       ex.printStackTrace();
                } catch (SQLException ex) {
                       ex.printStackTrace();
                }
                
try{
               String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
           
           Class.forName("com.mysql.cj.jdbc.Driver");
    
        Connection con = DriverManager.getConnection(url,username,password);
      PreparedStatement statement = con.prepareStatement("SELECT b.Title, a.name, b.Description, c.Name, b.Price " +
                                                           "FROM books b " + 
                                                           "JOIN authors_books ab ON b.Book_id = ab.Book_id " + 
                                                           "JOIN authors a ON a.author_id = ab.Author_id " + 
                                                           "JOIN category c ON b.Dictionary_id = c.Dictionary_id " + 
                                                           "WHERE b.Title = ?");
statement.setString(1, title_search);

try (ResultSet resultSet = statement.executeQuery()) {
  if (resultSet.next()) {
    String title = resultSet.getString("Title");
    String author = resultSet.getString("name");
    String description = resultSet.getString("Description");
    int price = resultSet.getInt("Price");

    JOptionPane.showMessageDialog(null, "Title: " + title + "\nAuthor: " + author + "\nDescription: " + description +"\nPrice: " + price +"\n"+"Buyrs:"+count_of_buyrs);
  } else {
    JOptionPane.showMessageDialog(null, "No book found with title: " + title_search);
  }
} catch (SQLException ex) {
  JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
}
}

catch (Exception e){
    e.printStackTrace();
}
              
                
                
                
                
                     }
                };
        
        String category = jComboBox1.getSelectedItem().toString();

        int minPriceValue = 0;
            int maxPriceValue =0;
 
      String str = minPrice.getText();
                String url = "jdbc:mysql://localhost:3306/digitalibrary";
           String username = "root";
           String password = "Amnbvcxz12#";
      Connection con1 = null;
      try{
   
        con1 = DriverManager.getConnection(url,username,password);
           
            minPriceValue = Integer.parseInt(str);
                       Class.forName("com.mysql.cj.jdbc.Driver");

            maxPriceValue = Integer.parseInt(maxPrice.getText());
        }
        catch (NumberFormatException ex){

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(homePage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(homePage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
int dictionaryId  =0 ;

    if (!"other".equals(category)){
String query = "SELECT dictionary_id FROM category WHERE name = '" + category + "'";

try (Statement stmt = con1.createStatement();
     ResultSet rs = stmt.executeQuery(query)) {

  if (rs.next()) {
     dictionaryId = rs.getInt("dictionary_id");
    System.out.println("The dictionary_id for name '" + category + "' is: " + dictionaryId);
  } 
    con1.close();

} catch (SQLException e) {
  System.err.println("Error while executing query: " + e.getMessage());
}        
    }


    String searchSQL = "SELECT b.Title, b.Description, b.Price FROM books b WHERE 1=1 ";


        try{
   
    
        Connection con2 = DriverManager.getConnection(url,username,password);

                if (minPriceValue != 0) {
                  searchSQL += "AND b.Price >= " + minPriceValue + " ";
                }

                if (maxPriceValue != 0) {
                  searchSQL += "AND b.Price <= " + maxPriceValue + " ";
                }

           

                if (!"other".equals(category) ) {
                  searchSQL += "AND b.Dictionary_id = " + dictionaryId + " ";
                }

                if (!"".equals(BookName.getText()) && !BookName.getText().isEmpty()) {
                  searchSQL += "AND b.Title = '" + BookName.getText() + "' ";
                }
                System.out.println(searchSQL);
                
                try (Statement statement = con2.createStatement();
                     ResultSet rs = statement.executeQuery(searchSQL)) {

                    
                DefaultTableModel model = new DefaultTableModel();
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();

           for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
              model.addColumn(metaData.getColumnLabel(columnIndex));

           
           }
                  model.addColumn("Buy");
                model.addColumn("Details");
                
                columnCount = model.getColumnCount();

        Object[] row = new Object[columnCount];
           while (rs.next()) {
                            for (int columnIndex = 0; columnIndex < columnCount -2; columnIndex++) {
                row[columnIndex] = rs.getObject(columnIndex + 1);
            }
                            
               JButton button = new JButton("Buy");
            JButton details = new JButton("Details");

            row[columnCount -2 ] = button;
            row[columnCount -1] = details;

            model.addRow(row);
                  }
            jLabel19.setText(""+model.getRowCount());
           
            jTable2.setModel(model);
            
             jTable2.getColumnModel().getColumn(3).setCellRenderer(new TableActionCellRender());
        
        jTable2.getColumnModel().getColumn(3).setCellEditor(new TableActionCellEditor(event));        

       jTable2.getColumnModel().getColumn(4).setCellRenderer(new TableActionCellRender1());
        
        jTable2.getColumnModel().getColumn(4).setCellEditor(new TableActionCellEditor1(details_event));   
        
        if (row.length == 0){
                    JOptionPane.showMessageDialog(null, "search results is empty", "Digital Library", JOptionPane.INFORMATION_MESSAGE);

        }
        
        con2.close();
        rs.close();
                } catch (SQLException e) {
                  // handle the exception
                }

        

    

        
            
        }catch(SQLException ex2){
            
                    System.out.println(ex2.toString());


            
        }        // TODO add your handling code here:
                    // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(homePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(homePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(homePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(homePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame page = null;
                try {
                    page = new homePage(1);
                } catch (Exception ex) {
                    Logger.getLogger(homePage.class.getName()).log(Level.SEVERE, null, ex);
                }
                page.setDefaultCloseOperation(0);

                page.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BookName;
    private javax.swing.JPanel Results;
    private javax.swing.JPanel SearchTools;
    private javax.swing.JPanel bg;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField maxPrice;
    private javax.swing.JTextField minPrice;
    private javax.swing.JPanel sidebar;
    // End of variables declaration//GEN-END:variables
}
